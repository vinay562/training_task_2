package com.example.student;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class indexController {
	
	@Autowired
	StudentRepository repository;

	@RequestMapping("/")
	public String getName()
	{
		return "index";
	}
	
	@RequestMapping("/home")
	public String getHome()
	{
		return "home";
	}
	@RequestMapping("/load")
	public String getLoad()
	{
		return "load";
	}
	@RequestMapping("/update")
	public String getSearch()
	{
		return "update";
	}
		
}
