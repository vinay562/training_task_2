package com.example.student;



import org.springframework.data.repository.CrudRepository;
import org.springframework.web.bind.annotation.RestController;
@RestController
public interface StudentRepository extends CrudRepository<Student,Long> {
	Student findBySection(String section);

}
