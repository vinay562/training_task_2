package com.example.student;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

@Service
public class StudentService {
	
	
	@Autowired
	StudentRepository studentrepository;
	public Model getForm(Model model) {
	        return model.addAttribute("student", new Student());
		}
	
    public List<Student> getAllDetail() {
    	//return model.addAttribute("student", studentrepository.findAll());
    	return (List<Student>) studentrepository.findAll();
    	
    }
    public void addDetails(Student st) {
    	studentrepository.save(st);
    }
    
    public Student getOneDetail(long id) {
    	return studentrepository.findOne(id);
    }
    public Student getDatailByName(String id) {
    	return studentrepository.findBySection(id);
    }
    public Student updateDetails(Student student) {
    	Student update=studentrepository.findOne(student.getId());
    	update.setName(student.getName());
    	update.setSection(student.getSection());
    	update.setAddress(student.getAddress());
    	update.setCity(student.getCity());
    	return studentrepository.save(update);
    }
    public void deleteDetails(long id) {
    	Student dlt=studentrepository.findOne(id);
    	studentrepository.delete(dlt);
    }
}
