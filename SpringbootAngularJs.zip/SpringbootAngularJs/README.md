# Student-Management-System
To Configure database connection ---> src\main\resources\application.properties
create table student{
        id  int(length) Primery Key,
        name varchar(length),
        section varchar(length),
        address varchar(length),
        city varchar(length)
        }
   
  To use this application,Please check your internet connection as i used cdn.
  
  For any issue or query feel free to contact me.
